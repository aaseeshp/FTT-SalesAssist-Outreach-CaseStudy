# FTT case study · SalesAssist AI-assisted advisor outreach: delivery

When a salesperson clicks the **email icon** next to a Financial Advisor in SalesAssist, a grounded, ready-to-edit email
appears. It comes with the reasons behind it, links to approved material only, and follow-up admin tasks that run
only after the user confirms them. Nothing is sent automatically.

## What's in this package

| # | Requested in the brief | File(s) |
|---|---|---|
| 1 | Short presentation for a non-technical sales audience | `01_Presentation/FT_Outreach_Assist.pptx` (15 slides, with speaker notes) |
| 2 | Architecture overview diagram (components, responsibilities, data flows) | `02_Architecture/architecture.svg` (open in any browser) and `02_Architecture/ARCHITECTURE.md` |
| 3 | Coding-agent conversation as a readable document | `03_Conversation/CONVERSATION.md` |
| 4 | Complete project with documentation and setup information | `04_Project/outreach-poc/` (see its `README.md` and `docs/`) |
| – | Planning material (plan, interactive data map) | `05_Planning/outreach-plan.html`, `05_Planning/data-map.html` |
| – | Source that generates the deck | `06_Deck_Source/` (`build.js` + app screenshots; for reference: it uses a theming helper from the author's tooling, so the `.pptx` in `01_Presentation` is the final artifact) |

Suggested reading order for a reviewer (about 15 minutes):
1. The presentation.
2. `04_Project/outreach-poc/README.md`, which includes a 5-minute demo script.
3. `docs/DECISIONS.md` and `docs/ASSUMPTIONS_AND_LIMITATIONS.md`.
4. Run the app locally (below).

All data is the synthetic sample data supplied with the case study. Document links are placeholders
(`example.invalid`). No credentials are included.

---

## How to host and run the prototype

The app is a single Python service (FastAPI). It serves both the API and the light HTML front end on one port.
It needs **no API key**: without one it runs the full rules pipeline and UI, and writes drafts from templates.
Add a Gemini or Claude credential to enable the CrewAI agents.

### Option A: Local, one command (tested on macOS, Python 3.11)

```bash
cd 04_Project/outreach-poc
./run.sh                       # first run creates .venv and installs dependencies (a few minutes)
# open http://localhost:8000
```

Manual equivalent:

```bash
cd 04_Project/outreach-poc
python3 -m venv .venv
.venv/bin/pip install -r requirements.txt && .venv/bin/pip install "anthropic==2.12.0"
.venv/bin/uvicorn app.main:app --port 8000
```

Run the tests with `.venv/bin/python -m pytest -q`. There are 27 tests; they need no network and make no model calls.

### Enabling the AI agents (optional)

Copy `.env.example` to `.env` in `04_Project/outreach-poc/` and set **one** of these:

| Provider | Settings | Notes |
|---|---|---|
| Gemini | `LLM_PROVIDER=gemini`, `GEMINI_API_KEY=…` | Model chain: `gemini-4-hydrogen`, then `3.8-flash`, then `3.5-flash`, then `3.5-flash-lite` (preview models are often busy, so it falls back automatically) |
| Claude | `LLM_PROVIDER=claude`, plus `ANTHROPIC_API_KEY=…` or a one-time `ant auth login` | `claude-sonnet-5-5`, then `claude-haiku-5-5`. The account needs API credits |
| None | `LLM_PROVIDER=template` | Rules and templates only. Fully offline |

The top-right badge in the app shows which engine is active. Each draft's "How this was prepared" panel shows which
model wrote it.

### Option B: Docker (Dockerfile included; not built in the authoring environment)

```bash
cd 04_Project/outreach-poc
docker build -t outreach-poc .
docker run --rm -p 8000:8000 -e LLM_PROVIDER=gemini -e GEMINI_API_KEY=<your key> outreach-poc
# open http://localhost:8000      (omit the -e flags for template mode)
```

Docker was not available on the machine used to build this package, so the image has not been built or tested.
The local option above is the verified path.

### Option C: Azure Container Apps (recommended cloud target; not deployed)

These are standard Azure CLI steps (`az login` first). Replace the names in `<>`.

```bash
az group create -n rg-outreach-poc -l eastus
az acr create -n <acrname> -g rg-outreach-poc --sku Basic --admin-enabled true
az acr build -r <acrname> -t outreach-poc:1 04_Project/outreach-poc

az containerapp env create -n cae-outreach-poc -g rg-outreach-poc -l eastus
az containerapp create -n outreach-poc -g rg-outreach-poc --environment cae-outreach-poc \
  --image <acrname>.azurecr.io/outreach-poc:1 --registry-server <acrname>.azurecr.io \
  --target-port 8000 --ingress external --min-replicas 1 --max-replicas 1 \
  --secrets gemini-key=<your key> \
  --env-vars LLM_PROVIDER=gemini GEMINI_API_KEY=secretref:gemini-key
```

Hosting notes for this POC:
- **Keep a single replica.** The draft cache and the admin-action log are held in memory. Production would use Redis
  for the cache and a database for the log, and re-compute drafts when data changes (via Service Bus).
- **There is no login in the POC.** The user switcher is a demo control. Before sharing a hosted URL, restrict
  access, for example with Container Apps authentication (Entra ID) or IP restrictions. In production, the user's
  region would come from their identity claims.
- **Store keys only as platform secrets,** never in the image or the repository.
- **Start-up:** the app checks which model responds, then pre-computes drafts in the background. With agents enabled,
  the first draft for each advisor takes about 30–60 seconds, and the cache serves every later click instantly.

### Viewing the other deliverables
- `.pptx` opens in PowerPoint, Keynote or Google Slides.
- `.svg` and `.html` files open in any web browser. They are self-contained, apart from web fonts.
- `.md` files read well on GitHub, in VS Code or in any Markdown viewer.
